/***************************************************************************
 *
 *  Sorting algorithms and counting work - Quicksort algorithm
 *   Aaron S. Crandall, 2017 <acrandal@gmail.com>
 *   For Educational use only
 *
 *  This .h provides an instrumented quicksort
 *
 */

#ifndef __INSTRUMENTEDQS_H
#define __INSTRUMENTEDQS_H

#include <vector>
#include "main.h"   // For SortStats struct definiton

using namespace std;

void instrumentedQuickSort( vector<int> & a, SortStats & stats )
{
	// MA TODO: implement quicksort and track compares + moves
}

#endif
