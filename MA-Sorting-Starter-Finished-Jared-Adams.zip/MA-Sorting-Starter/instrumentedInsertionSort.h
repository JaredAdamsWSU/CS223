/***************************************************************************
 *
 *  Sorting algorithms and counting work - Insertion sort algorithm
 *   Aaron S. Crandall, 2017 <acrandal@gmail.com>
 *   For Educational use only
 *
 *  This .h provides an instrumented insertionsort
 *
 */

#ifndef __INSTRUMENTEDIS_H
#define __INSTRUMENTEDIS_H

#include <vector>
#include "main.h"   // For SortStats struct definiton

using namespace std;

void instrumentedInsertionSort( vector<int> & a, SortStats & stats )
{
	// MA TODO: implement insertion sort plus logging compares, moves/swaps
  /*
  procedure insertionSort( A : array of items )
   int holePosition
   int valueToInsert

   for i = 1 to length(A) inclusive do:

       //select value to be inserted
      valueToInsert = A[i]
      holePosition = i

      //locate hole position for the element to be inserted

      while holePosition > 0 and A[holePosition-1] > valueToInsert do:
         A[holePosition] = A[holePosition-1]
         holePosition = holePosition -1
      end while

      // insert the number at hole position
      A[holePosition] = valueToInsert

   end for

  end procedure
  */
  int holePosition = 0;
  int valueToInsert = 0;

  for(int i = 1; i < a.size(); i++)
  {
    valueToInsert = a[i];
    holePosition = i;
    stats.compares++;

    while(holePosition > 0 && a[holePosition - 1] > valueToInsert)
    {
      a[holePosition] = a[holePosition - 1];
      holePosition = holePosition - 1;
      stats.compares+=2;
      stats.moves++;
    }
    a[holePosition] = valueToInsert;
    stats.moves++;
  }

}




#endif
