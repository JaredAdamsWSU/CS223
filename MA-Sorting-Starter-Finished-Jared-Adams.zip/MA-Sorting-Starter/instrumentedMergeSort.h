/***************************************************************************
 *
 *  Sorting algorithms and counting work - Merge sort algorithm
 *   Aaron S. Crandall, 2017 <acrandal@gmail.com>
 *   For Educational use only
 *
 *  This .h provides an instrumented mergesort
 *
 */

#ifndef __INSTRUMENTEDMS_H
#define __INSTRUMENTEDMS_H

#include <vector>
#include "main.h"   // For SortStats struct definiton

using namespace std;

void instrumentedMergeSort( vector<int> & a, SortStats & stats )
{
	// MA TODO: Implement Merge Sort plus logging compares and moves/swaps
  //split the initial list
  vector<int> leftList;
  vector<int> rightList;

  //create two arrays of the size of the
  leftList.resize(a.size()/2);
  rightList.resize(a.size() - leftList.size());
  stats.moves++;

  cout << "size of incoming array to be split: " << a.size() << endl;
  cout << "size of left array after split: " << leftList.size() << endl;
  cout << "size of right array after split: " << rightList.size() << endl;

  //begin recursing the lists
  if(a.size() == 1)
  {
    stats.compares++;
    return;
  }
  else
  {
    instrumentedMergeSort(leftList, stats);
    instrumentedMergeSort(rightList, stats);
  }
}


#endif
