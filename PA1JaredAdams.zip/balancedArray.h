
#ifndef _BALANCEDARRAY_H
#define _BALANCEDARRAY_H

extern const int balancedArray[];

#endif
